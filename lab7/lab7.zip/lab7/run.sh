clear
clear

make && echo "running lab7: " && ./lab7 < test.txt