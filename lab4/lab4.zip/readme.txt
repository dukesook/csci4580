Devon Sookhoo
Lab 4: The Symbol Table

This lab is an extension of lab3 where we used a symbol
table to keep track of a list of registers. In this lab,
we extended the registers to support names that are 
longer than a single character. We used Lex to tokenize
an input and YACC to apply a context free grammar.

Command to zip files:
$ zip -r lab4.zip readme.txt lab4.l lab4.y makefile symtable.c symtable.h tests/ csci4580_lab4_tests.pdf